# from pprint import pprint

from django.contrib import admin


from .models import MeditationExperiences,MeditationBenefits,YoutubeURLAddress






# class meditation_experiences(models.Model):

# =['user1','created','country','state','detail_address','benefited_in','benefit_brief_description',
# 'mobile','email','benefit_photo']


admin.site.site_header = 'BE PEACEFUL IN 5 MINUTE MEDITATION'
admin.site.site_title = 'AWAKEN THE KUNDALINI POWER WITIH US ONLINE '
admin.site.index_title = 'SAHAJAYOGA ONLINE MEDITATION FEEDBACK PORTAL'
admin.site.site_url = '#'



# class meditation_experiences(models.Model):


# =['user1','created','country','state','name',detail_address','benefited_in','benefit_brief_description',
# 'mobile','email','benefit_photo']


class MeditationExperiencesAdmin(admin.ModelAdmin):

    ordering = ('created',)

    list_display =['created','country','name','benefited_in','benefit_brief_description',
    'state','detail_address','mobile','email','benefit_photo']




    fieldsets =    [
                        ('passenger Information',
                        {'fields': 
                        ['country','name','benefited_in','benefit_brief_description',
    'state','detail_address','mobile','email','benefit_photo']

                        }  
                        ),
                    ]


    # fieldsets =    [
    #                     ('passenger Information',
    #                     {'fields': 
    #                     'country','name','benefited_in','benefit_brief_description',
    # 'state','detail_address','mobile','email','benefit_photo'


    #                     }  
    #                     ),
    #                 ]



    search_fields = ['country','state','name','detail_address','benefited_in',
    'benefit_brief_description','mobile','email']


    list_per_page = 6


admin.site.register(MeditationExperiences,MeditationExperiencesAdmin)

# class meditation_benefits(models.Model):
# =['user1','created','country','state','name','detail_address','benefited_in','benefit_brief_description',
# 'youtube_URL','mobile','email','benefit_photo','more_photo']



class MeditationBenefitsAdmin(admin.ModelAdmin):


    list_display =['created','country','name','benefited_in','benefit_photo',
    'benefit_brief_description','youtube_URL','mobile','email','more_photo','state','detail_address']




    fieldsets =    [
                        ('passenger Information',
                        {'fields': 
                        ['country','name','benefited_in','benefit_photo',
    'benefit_brief_description','youtube_URL','mobile','email','more_photo','state','detail_address']


                        }  
                        ),
                    ]



#     fieldsets =    [
#                         ('meditation_benefits_Admin Information',
#                         {'fields': 
                        
# 'user1','created','country','state','name',detail_address','benefited_in','benefit_brief_description',
# 'mobile','email','benefit_photo'


#                         }  
#                         ),
#                     ]








    search_fields  =['country','state','detail_address','benefited_in','benefit_brief_description',
'youtube_URL','mobile','email','benefit_photo','more_photo']


    list_per_page = 6



admin.site.register(MeditationBenefits,MeditationBenefitsAdmin)







# class youtube_URL_address(models.Model):
# =['user1','created','video_creator_name','video_label','benefited_in','video_brief_description','youtube_URL']


# from .models import MeditationExperiences,MeditationBenefits,YoutubeURLAddress


class YoutubeURLAddressAdmin(admin.ModelAdmin):

    ordering = ('created',)

    list_display =['user1','created','video_creator_name','video_label','benefited_in','video_brief_description','youtube_URL']






    fieldsets =    [
                        ('passenger Information',
                        {'fields': 
                        ['video_creator_name','video_label','benefited_in','video_brief_description','youtube_URL']

                        }  
                        ),
                    ]


    # fieldsets =    [
    #                     ('youtube_URL_address_Admin Information',
    #                     {'fields': 
    #                     'user1','created','video_creator_name','video_label','benefited_in','video_brief_description','youtube_URL'


    #                     }  
    #                     ),
    #                 ]




    search_fields =['video_creator_name','video_label','benefited_in','video_brief_description','youtube_URL']


    list_per_page = 6



admin.site.register(YoutubeURLAddress,YoutubeURLAddressAdmin)



