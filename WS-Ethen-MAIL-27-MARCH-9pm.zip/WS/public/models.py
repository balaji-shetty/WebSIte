from django.utils import timezone
from datetime import datetime
import datetime

from django.db import models

from django.utils.html import format_html
from datetime import date
from django.conf import settings

from multiselectfield import MultiSelectField





# from .models import MeditationExperiences,MeditationBenefits,YoutubeURLAddress

REPLY = (
    ('yes', 'Yes'),
    ('no', 'No'),
)


SEX = (
    ('male', 'Male'),
    ('female', 'Female'),
)

BENEFIT_CATEGORY = (
    ('health improved', 'Health improved'),
    ('family happy', 'Family happy'),
    ('disease normal', 'disease normal'),
    ('confidence increased', 'Confidence increased'),
    ('study_sleepiness_decrased', 'Study_sleepiness_decrased'),
    ('study_improved', 'Study_improved'),
    ('memory_improved', 'memory_improved'),
    ('smoking Quit', 'smoking Quit'),
    ('Drinking Quit', 'Drinking Quit'),
    ('Drug Habit QUit', 'Drug Habit QUit'),
    ('Feeling Peace of mind', 'Feeling Peace of mind'),
    ('Stress Free now', 'Stress Free now'),
    ('Fear Reduced', 'Fear Reduced'),
    ('Positive Thoughts', 'Positive Thoughts'),
    ('Anger Reduced', 'Anger Reduced'),

   )


YOUTUBE_CATEGORY = (
    ('new_seeker', 'New_seeker_Videos'),
    ('old_seeker', 'Old_seeker_Videos'),
    ('stress_management', 'stress_management_VIDEO'),
    ('scientific', 'scientific_Videos'),
    ('follow_up', 'Follow_up_Videos'),
    ('research', 'research_Videos'),
    ('experience', 'experience_Videos'),
    ('doctor', 'Doctor_Videos'),
    ('mataji_meditation', 'mataji_meditation_videos'),
    ('old_seeker_experiences', 'old_seeker_experiences_videos'),

   )


# , 'जिल्हा', 'तालुका', 'पत्ता', 'काय चूक घडत आहे त्याचे थोडक्यात वर्णन', 'जवळचे पोलिस स्टेशन', 'मोबाईल', 'पुरावा फोटो', 'अधिक फोटो', 'यूजर १'

class MeditationBenefits(models.Model):


# =['user1','created','country','state','name','detail_address','benefited_in','benefit_brief_description',
# 'youtube_URL','mobile','email','benefit_photo','more_photo']

    user1 = models.ForeignKey(settings.AUTH_USER_MODEL,
        null=True, blank=True, on_delete=models.SET_NULL)

    created = models.DateTimeField(auto_now=False, auto_now_add=True)

    country = models.CharField(max_length=30, default="INDIA")
    state = models.CharField(max_length=20, default="MH")
    name = models.CharField(max_length=30, default="BALAJI")
    detail_address = models.CharField(max_length=100, default="Enter Detail Address")
    address = models.CharField(max_length=100, default="Nanded")
    benefited_in = MultiSelectField(choices=BENEFIT_CATEGORY)

    benefit_brief_description = models.CharField(max_length=100, default="Nanded",verbose_name='काय चूक घडत आहे त्याचे थोडक्यात वर्णन')
    youtube_URL = models.URLField(max_length=50, null=True,blank=True)



    mobile = models.CharField(max_length=30,null=True, blank=True,default='Not Compulsory')
    email = models.EmailField(max_length=50,null=True, blank=True)
   
    benefit_photo = models.FileField(null=True,blank=True)
    more_photo = models.FileField(null=True, blank=True)

    class Meta:
        verbose_name = "meditation_benefits"
        verbose_name_plural = "meditation_benefits"


class YoutubeURLAddress(models.Model):
# =['user1','created','video_creator_name','video_label','benefited_in',
# 'video_brief_description','youtube_URL']


    user1 = models.ForeignKey(settings.AUTH_USER_MODEL,
        null=True, blank=True, on_delete=models.SET_NULL)

    created = models.DateTimeField(auto_now=False, auto_now_add=True)
    video_creator_name = models.CharField(max_length=40, default="Mataji Nirmala Devi")
    video_label = models.CharField(max_length=100, default="How to do Meditation video")
    benefited_in = MultiSelectField(choices=YOUTUBE_CATEGORY)

    video_brief_description = models.CharField(max_length=150, default="How Meditation changed my life")
    youtube_URL = models.URLField(max_length=50, null=True,blank=True)
    

    class Meta:
        verbose_name = "Youtube_URL_address"
        verbose_name_plural = "Youtube_URL_address"




class MeditationExperiences(models.Model):

# =['user1','created','country','state','name',detail_address','benefited_in','benefit_brief_description',
# 'mobile','email','benefit_photo']
    user1 = models.ForeignKey(settings.AUTH_USER_MODEL,
        null=True, blank=True, on_delete=models.SET_NULL)

    created = models.DateTimeField(auto_now=False, auto_now_add=True)

    country = models.CharField(max_length=30, default="INDIA")
    state = models.CharField(max_length=20, default="MH")
    name = models.CharField(max_length=20, default="Pls Enter Name")
    detail_address = models.CharField(max_length=100, default="Enter Detail Address")
    benefited_in = MultiSelectField(choices=BENEFIT_CATEGORY,verbose_name="I feel benefits in ")

    benefit_brief_description = models.CharField(max_length=100, 
        default="Please write your Meditation Experiences after doing online Meditation")
    
    mobile = models.CharField(max_length=30,null=True, blank=True,default='Not Compulsory')

    email=models.EmailField(max_length=200,null=True, blank=True)

    benefit_photo = models.FileField(null=True,blank=True,verbose_name="write experiences on paper & Upload")
   
    class Meta:
        verbose_name = "meditation_experience"
        verbose_name_plural = "meditation_experiences"

